package com.MahadevDas271998.Springbootazuredemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAzureDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
